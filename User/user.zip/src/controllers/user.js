const userModel = require("../models/user.model");
const userSettingsModel = require("../models/user-settings.model");
const bcrypt = require("bcrypt");

const jwt = require("jsonwebtoken");

async function register(req, res, next) {
  try {
    const { email, name, phone, password } = req.body;
    const existUser = await userModel.findOne({ where: { email } });

    if (existUser) {
      return res.status(400).json({ message: "email already exist" });
    }
    const hashPassword = await bcrypt.hash(password, 10);
    const newUser = await userModel.create({
      email,
      name,
      phone,
      password: hashPassword,
    });
    let userSettings;
    try {
      userSettings = await userSettingsModel.create({
        userid: newUser.id,
      });
    } catch (error) {
      await newUser.destroy();
      throw error;
    }

    res.status(201).json({ user: newUser, settings: userSettings });
  } catch (error) {
    next(error);
  }
}

async function login(req, res, next) {

  try {

    const { email, password } = req.body;
    // QUERY: Retrieve user from database by email address
    const existUser = await userModel.findOne({ where: { email } });
    // if (!existUser || bcrypt.compare(password, existUser.password)) {
    //  return res.status(400).json({ message: "invalid credintionals" });
    //}
    // VALIDATION: Verify both user existence and password match
    // CRITICAL FIX: Use bcrypt.compare() instead of direct string comparison
    // Direct comparison fails because stored password is hashed; bcrypt provides cryptographic validation
    const isPasswordValid = existUser && await bcrypt.compare(password, existUser.password);
    if (!isPasswordValid) {
      return res.status(400).json({ message: "Invalid credentials" });
    }
    // SECURITY: Generate JWT token using environment-based secret for production security
    // CRITICAL FIX: Replaced hardcoded "helloWorld" with JWT_SECRET from environment
    const token = jwt.sign({ id: existUser.id }, process.env.JWT_SECRET, {
      expiresIn: "1d",
    });
    res.json({ data: token });
  } catch (error) {
    next(error);
  }
}

async function getUserInfos(req, res, next) {
  try {
    const userId = req.params.id;
    const user = await userModel.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    let userSettings = await userSettingsModel.findOne({ where: { userid: userId } });
    if (!userSettings) {
      try {
        userSettings = await userSettingsModel.create({
          userid: userId,
        });
      } catch (error) {
        throw error;
      }
    }
    res.json({ user, settings: userSettings });
  } catch (error) {
    next(error);
  }
}

async function updateUserSettings(req, res, next) {
  try {
    const userId = req.params.id;
    const user = await userModel.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    const { profilevisibility, friendrequests, messages } = req.body;
    let settings = await userSettingsModel.findOne({ where: { userid: userId } });
    console.log(settings);
    if (!settings) {
      try {
        settings = await userSettingsModel.create({
          userid: userId,
          profilevisibility: profilevisibility || "public",
          friendrequests: friendrequests !== undefined ? friendrequests : true,
          messages: messages || "all",
        });
      } catch (error) {
        throw error;
      }
    } else {
      settings.profilevisibility = profilevisibility || settings.profilevisibility;
      settings.friendrequests = friendrequests !== undefined ? friendrequests : settings.friendrequests;
      settings.messages = messages || settings.messages;
      await settings.save();
    }
    res.json({ settings });
  } catch (error) {
    next(error);
  }

}


async function updateAvatarUser(req, res, next) {
  res.json({ message: "avatar updated" });
}

module.exports = { register, login, getUserInfos, updateUserSettings, updateAvatarUser };
